%% Donee ok
clc; close all; clear all;

% flight in low altitude. Low Mach
rho=1.225; T=281.651; gamma=1.4; R=287; a=(gamma*R*T)^0.5
M=0.294; V=M*a; g=9.81;
H=0;

m=120000; S=260; CMA=6.6; l=CMA; B=9720000;

% coefficient aerodynamic
Cz_alpha=5.80;
Cz_q=2.4924; % <0
Cz_deltam=0.45;  %%%%%%
Cm_alpha=-0.04; %%%%% determine la stabilite statique >0 => rascine positive  15
Cm_q=-15; %%%%%
Cm_deltam=-1.6; %%%%%
Cx=0.045

%Kch1=V*z_alpha/g
%% Oscillation d'incidence
% Matrix components for longitudinal modes OI ok
z_alpha=rho*V*S/2/m*Cz_alpha
z_q=rho*S*l/2/m*Cz_q
z_deltam=rho*V*S/2/m*Cz_deltam

m_alpha=rho*V^2*S*l/2/B*Cm_alpha
m_q=rho*V*S*l^2/2/B*Cm_q
m_deltam=rho*V^2*S*l/2/B*Cm_deltam

% Introduction of the matrix A,B,C,D ok
Aa=[-z_alpha 1-z_q; m_alpha m_q]
Ba=[-z_deltam ; m_deltam]
Ca=[1 0;0 1]
Da=[0; 0]

% Actuators
omega_act=1.4*2*pi %1.4*2*pi

% Gain allocation
K_alloc=1

K_nzc=1;
Kalpha=1
Kq=1
%% Gains de retour d'état. Command modal
% model de reference pour  système
ksi=0.7
omega=1  %10
lambda1=roots([1 2*ksi*omega omega*omega])
% prendre en compte integrateur
lambda=[lambda1; -omega_act]

sys_mat = linmod('V6_open_loop_sans_gains')
sysbo=ss(sys_mat.a,sys_mat.b,sys_mat.c,sys_mat.d)
rank(ctrb(sys_mat.a,sys_mat.b))

n=rank(ctrb(sys_mat.a,sys_mat.b))
VW1 = null([(sys_mat.a-lambda1(1)*eye(n)) sys_mat.b])
VW2 = null([(sys_mat.a-lambda1(2)*eye(n)) sys_mat.b])
Ky=-real([VW1(n+1) VW2(n+1)]*inv(sys_mat.c*[VW1(1:n) VW2(1:n)]+sys_mat.d*[VW1(n+1) VW2(n+1)]))
% Kx = place(sysbo.a,sysbo.b,lambda1);
% Ky = Kx*inv(sysbo.c-sysbo.d*Kx);
sysbf = feedback(sysbo,Ky);
damp(sysbf.a)


Kalpha=Ky(1)
Kq=Ky(2)
sysbf = linmod('V6_closed_loop_long_v2')
damp(sysbf.a)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % calcul de precommande
sys_closed_loop=linmod('V6_closed_loop_long_v2')
sysbf=ss(sys_closed_loop.a,sys_closed_loop.b,sys_closed_loop.c,sys_closed_loop.d)
K_nzc=inv(dcgain(sysbf(1,1)))
% damp(sysbf)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sys_closed_loop=linmod('V7_open_loop_long')
% sysbo_g=ss(sys_closed_loop.a,sys_closed_loop.b,sys_closed_loop.c,sys_closed_loop.d)
% %K_nzc=inv(dcgain(sysbf(2,1)))
% damp(sysbo_g)
% allmargin(-sysbo_g)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% bande passante de boucle ferme
 omega_bp=bandwidth(sysbf(1,1))



%% Modelisation closed loop system
%sys_mat=linmod('closed_loop_long_version2');
%sysbf=ss(sys_mat.a,sys_mat.b,sys_mat.c,sys_mat.d)
% Simulation temporelle 
% Initialisation
tfin = 20;
% Time
t = 0:0.01:tfin;
% input reference
E = [1*ones(size(t'))]
% simulation
[t,X,y] = sim('V6_closed_loop_long_v2',tfin,[],[t' E]);
% plot
figure; 
subplot(2,1,1)
plot(t,y(:,1),'red','MarkerSize',10,'LineWidth',1)
grid on;
hold on
title('alpha');
subplot(2,1,2)
plot(t,y(:,2),'red','MarkerSize',10,'LineWidth',1)
grid on;
hold on
title('q');
% subplot(4,1,3)
% plot(t,y(:,3),'red','MarkerSize',10,'LineWidth',2)
% grid on;
% hold on
% title('deflection');
% subplot(4,1,4)
% plot(t,y(:,4),'red','MarkerSize',10,'LineWidth',2)
% grid on;
% hold on
% title('error');





