%% Donee
clc; close all; clear all;

% flight in low altitude. Low Mach
rho=1.225; T=281.651; gamma=1.4; R=287; a=(gamma*R*T)^0.5
M=0.23; V=M*a; g=9.81;
H=1005.8;

m=90928; S=313.2; CMA=7.433; l=CMA; B=9720000; A=2042546; C=3424933;

%% Oscillation de derapage, mode roulis pur, 
% Matrix components for longitudinal modes OI
y_beta=-0.107
n_beta=2.498
n_r=-1.738
n_p=-0.332
l_beta=-3.932
l_r=2.391
l_p=-7.552
l_delta_l=-0.56


% Introduction of the matrix A,B,C,D
Aa=[y_beta -1 0 g/V; n_beta n_r n_p 0; l_beta l_r l_p 0; 0 0 1 0]
%Ba=[0 0 0 0; n_delta_l_LO -n_delta_l_LI n_delta_l_RI n_delta_l_RO; l_delta_l_LO 0 0 l_delta_l_RO; 0 0 0 0]
%Ba=[0 0 0 0; l_delta_l -l_delta_l 0.8*l_delta_l l_delta_l; l_delta_l 0.8*l_delta_l -0.8*l_delta_l -l_delta_l; 0 0 0 0]
%Ba=[0.1 0.2 0.3 0.7; l_delta_l -0.8*l_delta_l 0.8*l_delta_l l_delta_l; l_delta_l 0.8*l_delta_l -0.8*l_delta_l -l_delta_l; 0 0 0 0]
%Ba=[0 0 0 0; l_delta_l l_delta_l l_delta_l l_delta_l; l_delta_l 0 0 -l_delta_l; 0 0 0 0]
%Ba=[0.05 0.06 0.07 0.08; l_delta_l 0.8*l_delta_l 0.8*l_delta_l l_delta_l; l_delta_l 0.8*l_delta_l -0.8*l_delta_l -l_delta_l; 0 0 0 0]
B = [0.4264 2.3639; -0.8314 -1.8519; -67.2281 4.9625; 0 0]
Kalloc_BO = [1 1; 0 -1; 0 0; -1 0]
Ba = mrdivide(B,Kalloc_BO)

Ca=eye(4)
Da=zeros(4)

% Actuators
omega_act=1.4*2*pi %1.4*2*pi
ksi_act=0.7

% RMT schema
omega_0=1*2*pi
ksi_0=0.7

% Gains de retour
%K_alloc=[1;1;1;1]
Kp_beta=1; Kpr=1; Kpp=1; Kp_fi=1;
Kr_beta=1; Krr=1; Krp=1; Kr_fi=1;
Kip_beta=1; Kir_beta=1;
K_alloc_dn = 1; K_alloc_dl = 1;

% Kr_beta_pos=ky(1)
% Krr_pos=ky(2)
% Krp_pos=ky(3)
% Kr_fi_pos=ky(4)
% Kir_beta_pos=-ky(5)
% 
% Kr_beta_negat=ky(1)
% Krr_negat=ky(2)
% Krp_negat=ky(3)
% Kr_fi_negat=ky(4)
% Kir_beta_negat=-ky(5)
% 
% Kp_beta=ky(1)
% Kpr=ky(2)
% Kpp=ky(3)
% Kp_fi=ky(4)
% Kip_beta=-ky(5)

% RMT schema beta
omega_RMT=0.4
ksi_RMT=0.7
Kch=1

% RMT schema fi
tau1=1.6
tau2=1.9
denom=[tau1*tau2 (tau1+tau2) 1]


%Gains de precommande
K_fi_c=1;
K_beta_c=1;

%% 1 RMT synhtese. H_inf
% D'abord on fait optimisation pour chercher min de la norme H2. Apr�s on
% rajoute les contraintes

st=slTuner('V7_closed_loop_lat_version5_Switch_beta',...
{'Kp_beta1','Kpr1','Kpp1','Kp_fi1',...
 'Kr_beta1','Krr1','Krp1','Kr_fi1',...
 'Kip_beta1','Kir_beta1','K_beta_c',...
 'K_alloc_dl','K_alloc_dn'});

addPoint(st,{'beta_c','beta_ref','z_1','beta','Z2'})

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T=getIOTransfer(st,'beta_c','beta_ref')
T1=ss(T)
dcgain(T1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T=getIOTransfer(st,'beta_c','beta')
T2=ss(T)
dcgain(T2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Tracking changing gain

opt = systuneOptions('RandomStart',10)
Perf1=TuningGoal.Gain('beta_c',{'z_1'},1)

%tuning with taking into account requirenments
[st1,fSoft,gHard]=systune(st,Perf1,[],opt)

%viewSpec
% Verify that the tuned system satisfies the requirement
viewSpec(Perf1,st1)

% reponse temporelle
figure
t=getIOTransfer(st,'beta_c','z_1')
t1=getIOTransfer(st1,'beta_c','z_1')
step(t1)
legend('initial','tuned')
hold on

figure
t=getIOTransfer(st,'beta_c','beta_ref')
t1=getIOTransfer(st1,'beta_c','beta')
step(t,t1)
legend('RMT \beta response','Tuned scheme \beta response')
hold on


% get optimized values of gains
% Kp_beta = getBlockValue(st1,'Kp_beta1')
% Kpr = getBlockValue(st1,'Kpr1')
% Kpp = getBlockValue(st1,'Kpp1')
% Kp_fi = getBlockValue(st1,'Kp_fi1')
% 
% Kr_beta = getBlockValue(st1,'Kr_beta1')
% Krr = getBlockValue(st1,'Krr1')
% Krp = getBlockValue(st1,'Krp1')
% Kr_fi = getBlockValue(st1,'Kr_fi')
% 
% Kip_beta = getBlockValue(st1,'Kip_beta1')
% Kir_beta = getBlockValue(st1,'Kir_beta1')
% 
% 
% Kp_beta = Kp_beta.d
% Kpr = Kpr.d
% Kpp = Kpp.d
% Kp_fi = Kp_fi.d
% Kr_beta = Kr_beta.d
% Krr = Krr.d
% Krp = Krp.d
% Kr_fi = Kr_fi.d
% Kip_beta = Kip_beta.d
% Kir_beta = Kir_beta.d

%% 2 RMT synhtese. H2/H_inf
st=slTuner('V7_closed_loop_lat_version5_Switch_beta',...
{'Kp_beta1','Kpr1','Kpp1','Kp_fi1',...
 'Kr_beta1','Krr1','Krp1','Kr_fi1',...
 'Kip_beta1','Kir_beta1','K_beta_c',...
 'K_alloc_dl','K_alloc_dn'});

addPoint(st,{'beta_c','beta_ref','z_1','beta','Z2',...
            'fi'})%,'fi_c','z_2','fi_ref'})

opt = systuneOptions('RandomStart',10)
Perf2=TuningGoal.Gain('beta_c','z_1',1.1*fSoft);
energie=TuningGoal.Variance('beta_c','Z2',1);

%tuning with taking into account requirenments
[st2,fSoft2,gHard2]=systune(st,energie,Perf2,opt)

% Verify that the tuned system satisfies the requirement
viewSpec(Perf2,st2)


% get optimized values of gains

% reponse temporelle
figure
t=getIOTransfer(st1,'beta_c','z_1')
t1=getIOTransfer(st2,'beta_c','z_1')
step(t,t1)
legend('initial','tuned')

figure
t=getIOTransfer(st1,'beta_c','beta')
t1=getIOTransfer(st2,'beta_c','beta')
step(t,t1)
legend('initial','tuned')

figure
t=getIOTransfer(st1,'beta_c','Z2')
t1=getIOTransfer(st2,'beta_c','Z2')
step(t,t1)
legend('initial','tuned')
  
