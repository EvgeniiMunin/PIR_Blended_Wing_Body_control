%% Donee ok
clc; close all; clear all;

% flight in low altitude. Low Mach
rho=1.225; T=281.651; gamma=1.4; R=287; a=(gamma*R*T)^0.5
M=0.294; V=M*a; g=9.81;
H=0;

m=120000; S=260; CMA=6.6; l=CMA; B=9720000;

% coefficient aerodynamic (ï¿½ ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½)
Cz_alpha=5.80;
Cz_q=2.4924; % <0
Cz_deltam=0.45;  %%%%%%
Cm_alpha=-0.04; %%%%% determine la stabilite statique >0 => rascine positive  15
Cm_q=-15; %%%%%
Cm_deltam=-1.6; %%%%%
Cx=0.045

%Kch1=V*z_alpha/g
%% Oscillation d'incidence
% Matrix components for longitudinal modes OI
z_alpha=rho*V*S/2/m*Cz_alpha
z_q=rho*S*l/2/m*Cz_q
z_deltam=rho*V*S/2/m*Cz_deltam

m_alpha=rho*V^2*S*l/2/B*Cm_alpha
m_q=rho*V*S*l^2/2/B*Cm_q
m_deltam=rho*V^2*S*l/2/B*Cm_deltam

% Introduction of the matrix A,B,C,D
Aa=[-z_alpha 1-z_q; m_alpha m_q]
Ba=[-z_deltam ; m_deltam]
Ca=[1 0;0 1;(V/g*z_alpha+l/g*m_alpha) (-V/g*(1-z_q)+l/g*m_q)]
Da=[0; 0; (V/g*z_deltam+l/g*m_deltam)]

% Actuators
omega_act=1.4*2*pi %1.4*2*pi


% RMT schema
omega_0=1*2*pi
ksi_0=0.7

% Gain allocation
%K_alloc=[1;1;1;1]
K_alloc=1

K_nzc=1;
Ki=1
Kq=1
Knz=1
%% Gains de retour d'état. Command modal
% model de reference pour  système
ksi=0.7
omega=1  %10
lambda=roots([1 2*ksi*omega omega*omega])
% prendre en compte integrateur
lambda=[lambda]

ky=1; K_nzc=1;
sys_mat = linmod('V6_open_loop_sans_gains')
sysbo=ss(sys_mat.a,sys_mat.b,sys_mat.c,sys_mat.d)
 allmargin(-sysbo(2,1))
damp(sysbo)
% verifier contralabilit�. il faut avoir n=rank
rank(ctrb(sys_mat.a,sys_mat.b))

n=2
% calcul de gain de retoure
VW1 = null([(sys_mat.a-lambda(1)*eye(n)) sys_mat.b])
VW2 = null([(sys_mat.a-lambda(2)*eye(n)) sys_mat.b])
%ky=-real([VW1(n+1) VW2(n+1) VW3(n+1)]*inv(sys_mat.c*[VW1(1:n) VW2(1:n) VW3(1:n)]+sys_mat.d*[VW1(n+1) VW2(n+1) VW3(n+1)]))
%ky=-real([VW1(n+1) VW2(n+1) VW3(n+1)]*inv([VW1(1:n) VW2(1:n) VW3(1:n)]+sys_mat.d*[VW1(n+1) VW2(n+1) VW3(n+1)]))
ky=-real([VW1(n+1) VW2(n+1)]*inv([VW1(1:n) VW2(1:n)]))

% Vérification:
damp(feedback(sysbo,ky))

Kq=ky(1)
Knz=ky(2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calcul de precommande
sys_closed_loop=linmod('V6_closed_loop_long')
sysbf=ss(sys_closed_loop.a,sys_closed_loop.b,sys_closed_loop.c,sys_closed_loop.d)
%K_nzc=inv(dcgain(sysbf(2,1)))
damp(sysbf)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sys_closed_loop=linmod('V7_open_loop_long')
sysbo_g=ss(sys_closed_loop.a,sys_closed_loop.b,sys_closed_loop.c,sys_closed_loop.d)
%K_nzc=inv(dcgain(sysbf(2,1)))
damp(sysbo_g)
allmargin(-sysbo_g)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% bande passante de boucle ferme
omega_bp=bandwidth(sysbf(2,1))



%% Modelisation closed loop system
%sys_mat=linmod('closed_loop_long_version2');
%sysbf=ss(sys_mat.a,sys_mat.b,sys_mat.c,sys_mat.d)
% Simulation temporelle 
% Initialisation
tfin = 20;
% Time
t = 0:0.01:tfin;
% input reference
E = [1*ones(size(t'))]
% simulation
[t,X,y] = sim('V6_closed_loop_long',tfin,[],[t' E]);
% plot
figure; 
subplot(2,1,1)
plot(t,y(:,1),'red','MarkerSize',10,'LineWidth',1)
grid on;
hold on
title('q');
subplot(2,1,2)
plot(t,y(:,2),'red','MarkerSize',10,'LineWidth',1)
grid on;
hold on
title('n_z');
% subplot(4,1,3)
% plot(t,y(:,3),'red','MarkerSize',10,'LineWidth',2)
% grid on;
% hold on
% title('deflection');
% subplot(4,1,4)
% plot(t,y(:,4),'red','MarkerSize',10,'LineWidth',2)
% grid on;
% hold on
% title('error');


%% Synthèse H_inf
% D'abord on fait optimisation pour chercher min de la norme H2. Après on
% rajoute les contraintes
% RMT schema
omega_RMT=1
ksi_RMT=0.7
Kch=1

st=slTuner('V8_tuned_closed_loop_long_RMT',{'Command load factor feedforward','Integral Gain','Pitch Rate Feedback','Load Factor Feedback'})
addPoint(st,{'Nzc','z_1','Z2','nz','nz_ref','alpha'})

T_nzc_nz=getIOTransfer(st,'Nzc','nz')
T_nzc_alpha=getIOTransfer(st,'Nzc','alpha')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ok
% TRSS=ss(Aa,Ba,Ca,Da)
% GSt=dcgain(TRSS)
% Kch=GSt(3)/GSt(1)
% Kch=dcgain(T_nzc_nz)/dcgain(T_nzc_alpha)
 Kch=-V*z_alpha/g
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ok
T1_nzc_ref=getIOTransfer(st,'Nzc','nz_ref')
T1=ss(T1_nzc_ref)
dcgain(T1)

T2=ss(T_nzc_alpha)
dcgain(T2)
dcgain(T2*Kch)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ok
T3_z1=getIOTransfer(st,'Nzc','z_1')
T3=ss(T3_z1)
dcgain(T3)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
opt = systuneOptions('RandomStart',10)
Perf1=TuningGoal.Gain('Nzc','z_1',1); 

%tuning with taking into account requirenments
[st1,fSoft,gHard]=systune(st,Perf1,[],opt) 

%viewSpec
% Verify that the tuned system satisfies the requirement
viewSpec(Perf1,st1)
figure

% get optimized values of gains
K_nzc = getBlockValue(st1,'Command load factor feedforward')
Ki = getBlockValue(st1,'Integral Gain')
Kq = getBlockValue(st1,'Pitch Rate Feedback')
Knz = getBlockValue(st1,'Load Factor Feedback')

% reponse temporelle
t=getIOTransfer(st,'Nzc','z_1')
t1=getIOTransfer(st1,'Nzc','z_1')
step(t1)
legend('initial','tuned')

figure
t=getIOTransfer(st,'Nzc','nz')
t1=getIOTransfer(st1,'Nzc','nz')
step(t1)
legend('initial','tuned')
  
figure
t1=getIOTransfer(st1,'Nzc','alpha')
step(t1)
legend('initial','tuned')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T_nzc_z1=getIOTransfer(st1,'Nzc','z_1')
T=ss(T_nzc_z1)
bode(T)
norm(T,Inf)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K_nzc = K_nzc.d
Ki = Ki.d
Kq = Kq.d
Knz = Knz.d

%%

t1 = getIOTransfer(st1,'Nzc','z_1')
%% RMT Schema. Performance. Minimisation de l'energie. H2/H_inf
% RMT schema
%omega_RMT=1
%ksi_RMT=0.7
%Kch=-V*z_alpha/g


st=slTuner('V8_tuned_closed_loop_long_RMT',{'Command load factor feedforward','Integral Gain','Pitch Rate Feedback','Load Factor Feedback'})
addPoint(st,{'Nzc','z_1','Z2','nz','alpha','nz_ref'})

% Changing tracking signal
% T_nzc_nz=getIOTransfer(st,'Nzc','nz')
% T_nzc_alpha=getIOTransfer(st,'Nzc','alpha')
% Kch=dcgain(T_nzc_nz)/dcgain(T_nzc_alpha)

%Perf1=TuningGoal.Gain('Nzc','Z1',tf([0 0.5],[1 0.5]));
opt = systuneOptions('RandomStart',10)
Perf2=TuningGoal.Gain('Nzc','z_1',1.1*fSoft);
energie=TuningGoal.Variance('Nzc','Z2',1);
%pole=TuningGoal.Poles(0.06,0.5,Inf);

%tuning with taking into account requirenments
[st2,fSoft2,gHard2]=systune(st,energie,Perf2,opt)

%viewSpec
% Verify that the tuned system satisfies the requirement
viewSpec(Perf2,st2)
% viewSpec(pole,st2)
figure

% get optimized values of gains
K_nzc = getBlockValue(st2,'Command load factor feedforward')
Ki = getBlockValue(st2,'Integral Gain')
Kq = getBlockValue(st2,'Pitch Rate Feedback')
Knz = getBlockValue(st2,'Load Factor Feedback')

% reponse temporelle
t=getIOTransfer(st,'Nzc','z_1')
t1=getIOTransfer(st2,'Nzc','z_1')
step(t,t1)
legend('initial','tuned')

K_nzc = K_nzc.d
Ki = Ki.d
Kq = Kq.d
Knz = Knz.d

  figure
  t=getIOTransfer(st,'Nzc','nz')
  t1=getIOTransfer(st1,'Nzc','nz')
  step(t1)
  legend('initial','tuned')
  
  figure
  t1=getIOTransfer(st1,'Nzc','alpha')
  step(t1)
  legend('initial','tuned')
%  
%   figure
%   t=getIOTransfer(st,'Nzc','Z2')
%   t1=getIOTransfer(st1,'Nzc','nz_ref')
%   step(t1)
%   legend('initial','tuned')
%% Verification de l'optimisation
% energie. on verifie le norme H_2 pour les cas initial et tune
T1=ss(t1)
T=ss(t)
norm(T,2)
norm(T1,2)

% stabilité. allmargin BO avec retour de sortie
sys_mat=linmod('V7_open_loop_long');
sysbov=ss(sys_mat.a,sys_mat.b,sys_mat.c,sys_mat.d)
allmargin(-sysbov(1,1))
rltool(-sysbov(1,1))
bode(-sysbov(1,1))





