%**************************************************************************
% Satellite antenna position control system
%**************************************************************************
% Author : Caroline B�rard
% Octobre 2016 
%**************************************************************************
%%
clc; close all; clear all;
Re = 2; Le = 0.002; ke = 0.2; kg = 0.2; 
J = 0.002; N = 300;
kci = 1; kcv = 0.0314; kcp = 1;

pert = 7;
tfin = 6;
tf1 = 2;
tf2 = 4;
noise = 0.1;
%%
%**************************************************************************
% Retour de sortie sur le mod�le d'ordre 3
%**************************************************************************
% On cherche les gains Kp et Kv pour imposer une dynamique en boucle ferm�e.
% On doit donc choisir les modes Lambda que l'on cherche � placer en boucle
% ferm�e. 
% On peut envisager de faire varier les p�les ou la fr�quence des poles
% pour voir l'influence de ces choix.
% il faut �galement calculer la pr�commande correspondante

cci = ['b','r','g','m'];
ii = 0;
qsi = 0.7;
w = 30;
%lambda=roots([1 2*qsi*omega omega^2]);
%L1=lambda(1);
%L2=lambda(2);
%    G=sys_open_loop([1 2], 1);

%for w = [10 20 30] 
    lambda = roots([1 2*qsi*w w*w]);
    ii = ii+1;
    hy = 1;
    ky = 1;
    sys_open_loop = linmod('open_loop_system_without_current1');
    
    % calcul du retour de sortie
    VW1 = null([sys_open_loop.a-lambda(1)*eye(3) sys_open_loop.b]);
    VW2 = null([sys_open_loop.a-lambda(2)*eye(3) sys_open_loop.b]);
    ky = -real([VW1(4) VW2(4)]*inv(sys_open_loop.c*[VW1(1:3) VW2(1:3)]));
    % calcul de la pr� commande
    sys_closed_loop = linmod('closed_loop_system_without_current');
    sys_closed_loop = ss(sys_closed_loop.a, sys_closed_loop.b, ...
        sys_closed_loop.c, sys_closed_loop.d);
    hy = inv(dcgain(sys_closed_loop(1,1)));
    damp (sys_closed_loop);
    % simulation
    tt = 'closed_loop_system_without_current'; %model
    cc = cci(ii);
    simulation
%end
legend('w1','w2','w3');

%%
%**************************************************************************
% A partir d'un mod�le en boucle ouverte comportant le syst�me et la loi de
% commande et en utilisant la fonction rltool de Matlab vous visualiserez 
% l'effet de votre loi de commande dans un lieu des racines
%**************************************************************************
close all
sysm =linmod('open_loop_system_lr');
sys =ss(sysm.a,sysm.b,sysm.c,sysm.d);
sys=-sys;
ftbo = rltool(sys(1,2));

%%
%**************************************************************************
% calcul des marges de robustesse. Celles ci sont calcul�es � partir d'un
% mod�le en boucle ouverte comportant le syst�me et la loi de
% commande et en utilisant la fonction "allmargins" de Matlab
%**************************************************************************
allmargin(sys(1,2));

%%
%**************************************************************************
% retour de sortie sur le mod�le d'ordre 2
%**************************************************************************
% La synth�se �tant faite sur le mod�le d'ordre 2, on est dans le cas o� le nombre de mesure est �gal � la dimension du vecteur
% d'�tat. On peut utiliser la fonction "place" de matlab 

close all;
sys_open_loop = linmod('open_loop_system_ordre2');
sys_open_loop = ss(sys_open_loop.a,sys_open_loop.b,sys_open_loop.c,sys_open_loop.d);
tf(sys_open_loop(1,1))
w=30;
lambda = roots([1 2*qsi*w w*w]);
Kx = place(sys_open_loop.a,sys_open_loop.b,lambda);
ky = Kx*inv(sys_open_loop.c);
% les gains sont synth�tis�s sur le mod�le d'ordre 2 mais valid�s sur le
% mod�le complet d'ordre 3
hy = 1;
sys_closed_loop = linmod('closed_loop_system_without_current');
sys_closed_loop = ss(sys_closed_loop.a, sys_closed_loop.b, ...
    sys_closed_loop.c, sys_closed_loop.d);
damp(sys_closed_loop.a)
hy = inv(dcgain(sys_closed_loop(1,1)));
% simulation temporelle
tt = 'closed_loop_system_without_current';
simulation
  

%%
%**************************************************************************
% retour de sortie avec int�grateur
%**************************************************************************
% On cherche maintant � annuler l'erreur due � la perturbation, on va donc
% introduire un int�grateur dans la loi de commande. La synth�se peut se
% faire sur le mod�le d'ordre 2 ou d'ordre 3. 
% La d�marche consiste � construire un syst�me boucle ouverte avec
% int�grateur, (ordre 3 ou ordre 4) puis � faire comme pr�c�dement un
% placement de pole pour calculer les 3 gains, vitesse, position et
% integrale de l'erreur. 
% Comme pr�c�dement on impl�mente ces gains dans un sch�ma Simulink boucle
% ferm�e pour faire les simulations temporelles 
 w = 30;
 lambda = roots([1 2*qsi*w w*w]);
 lambda=[lambda; -w];
 int=1;
   
    ii = ii+1;
    hy = 2400;
    ky = 1;
    
    sys_open_loop = linmod('open_loop_system_without_current_int');
    
    % calcul du retour de sortie
    VW1 = null([sys_open_loop.a-lambda(1)*eye(4) sys_open_loop.b]);
    VW2 = null([sys_open_loop.a-lambda(2)*eye(4) sys_open_loop.b]);
    VW3 = null([sys_open_loop.a-lambda(3)*eye(4) sys_open_loop.b]);

    ky = -real([VW1(5) VW2(5) VW3(5)]*inv(sys_open_loop.c*[VW1(1:4) VW2(1:4)  VW3(1:4)]));
    % calcul de la pr� commande
    sys_closed_loop = linmod('closed_loop_system_without_current_int');
    sys_closed_loop = ss(sys_closed_loop.a, sys_closed_loop.b, ...
        sys_closed_loop.c, sys_closed_loop.d);
   % hy = inv(dcgain(sys_closed_loop(1,1)));
    damp (sys_closed_loop);
    % simulation
    tt = 'closed_loop_system_without_current_int'; %model
  %  cc = cci(ii);
    simulation

%**************************************************************************
% calcul des marges de rob%**************************************************************************
% Satellite antenna position control system
%**************************************************************************
% Author : Caroline B�rard
% Octobre 2016 
%%
%**************************************************************************
% Initialisation
tt='open_loop_system_without_current_int';
tfin = 20;
tf1 = 7;
tf2 = 13;
%**************************************************************************
% simulation
%**************************************************************************
% Time
t = 0:0.01:tfin;
t1 = 0:0.01:tf1;
t2 = tf1+0.01:0.01:tf2;
t3 = tf2+0.01:0.01:tfin;
% input reference
E = [10*ones(size(t')) [zeros(size(t1'));pert*ones(size(t2'));...
    pert*ones(size(t3'))] ...
   [zeros(size(t1'));zeros(size(t2'));noise*sin(20*t3')]];
% simulation
[t,X,y] = sim(tt,tfin,[],[t' E]);
%**************************************************************************
% Temporal response
%**************************************************************************
figure(1)
subplot(2,1,1)
plot(t,y(:,1),cc,'MarkerSize',10,'LineWidth',2)
hold on
title('position');
subplot(2,1,2)
plot(t,y(:,2),cc,'MarkerSize',10,'LineWidth',2)
hold on
title('commande');
 
%**************************************************************************
% les marges sont calcul�es � partir d'unmod�le en boucle ouverte comportant 
% le syst�me et la loi de commande et en utilisant la fonction "allmargins" 
% de Matlab
